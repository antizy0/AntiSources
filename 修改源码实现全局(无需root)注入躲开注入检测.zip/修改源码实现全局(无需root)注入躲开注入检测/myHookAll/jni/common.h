#ifndef _COMMON_H
#define _COMMON_H
#include <android/log.h>
#define LOG_TAG "snow_soHook"
#define LOGE(...)    __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

#endif